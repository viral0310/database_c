import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DBHelper {
  DBHelper._();
  static final DBHelper dbHelper = DBHelper._();

  final String dbName = 'demo.db';
  final String tableName = 'Student';

  final String colId = 'id';
  final String colName = 'name';
  final String colAge = 'age';
  final String colCity = 'city';

  Database? db;

  // TODO: initDB();
  Future<void> initDB() async {
    String directory = await getDatabasesPath();
    String path = join(directory, dbName);

    db = await openDatabase(path, version: 1,
        onCreate: (Database db, int version) async {
      String query =
          "CREATE TABLE IF NOT EXISTS $tableName($colId INTEGER PRIMARY KEY AUTOINCREMENT,$colName TEXT,$colAge INTEGER, $colCity TEXT);";

      await db.execute(query);

      print("----------------------------------");
      print("Table created successfully");
      print("------------------------------------");
    });
  }

  // TODO: insertRecord();
  Future<int> insertRecord() async {
    await initDB();
    String name = 'shag-ar';
    String city = 'Mumbai';
    int age = 20;

    String query =
        "INSERT INTO $tableName($colName,$colAge,$colCity) VALUES(?, ?, ?);";

    List args = [name, age, city];

    int id = await db!.rawInsert(query, args);
    print(args);
    return id;
  }

// TODO: fetchAllRecords();
  Future<List<Map<String, dynamic>>> fetchAllRecords() async {
    await initDB();

    String query = "SELECT * FROM $tableName";

    List<Map<String, dynamic>> allStudents = await db!.rawQuery(query);
    print(allStudents);
    return allStudents;
  }
// TODO: updateRecord();

// TODO: deleteRecords();

  // TODO: fetchSearchedRecords();
}
