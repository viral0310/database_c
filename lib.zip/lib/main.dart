import 'package:flutter/material.dart';
import 'package:sql_lite/db%20helper.dart';

void main() {
  runApp(
    const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyApp(),
    ),
  );
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("SQLite App"),
        centerTitle: true,
      ),
      body: FutureBuilder(
        future: DBHelper.dbHelper.fetchAllRecords(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text("${snapshot.error}"),
            );
          } else if (snapshot.hasData) {
            List<Map<String, dynamic>> data =
                snapshot.data as List<Map<String, dynamic>>;

            return ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, i) {
                return Card(
                  elevation: 3,
                  child: ListTile(
                    leading: Text("${data[i]['id']}"),
                    title: Text("${data[i]['name']}"),
                    subtitle: Text("${data[i]['age']}"),
                    trailing: Text("${data[i]['city']}"),
                  ),
                );
              },
            );
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          int id = await DBHelper.dbHelper.insertRecord();

          if (id > 0) {
            print("--------------------------------");
            print("Recorde inserted successfully with id of $id");
            print("---------------------------------");
          } else {
            print("---------------------------------");
            print("Record inserted failed.........");
            print("----------------------------------");
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
